"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { DashboardHeader } from "@/components/dashboard-header"

interface UserData {
  name: string
  email: string
}

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const [user, setUser] = useState<UserData | null>(null)
  const router = useRouter()

  useEffect(() => {
    // Check if user is authenticated
    fetch("http://localhost:5000/api/auth/check", { credentials: "include" })
      .then((res) => res.json())
      .then((data) => {
        if (!data.authenticated) {
          router.push("/login?redirect=/dashboard")
          return
        }

        // Fetch user data
        return fetch("http://localhost:5000/api/auth/me", { credentials: "include" }).then((res) => res.json())
      })
      .then((userData) => {
        if (!userData) return
        setUser({
          name: userData.name,
          email: userData.email,
        })
      })
      .catch((err) => {
        console.error("Error fetching user data:", err)
      })
  }, [router])

  const handleLogout = async () => {
    await fetch("http://localhost:5000/api/auth/logout", {
      method: "POST",
      credentials: "include",
    })
    router.push("/")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} onLogout={handleLogout} />
      <main className="flex-1">{children}</main>
    </div>
  )
}
