"use client"

import { useState, useEffect } from "react"
import { useParams, notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { User } from "lucide-react"
import Link from "next/link"
import { ProfileHeader } from "@/components/profile/profile-header"
import { ProfileSnippets } from "@/components/profile/profile-snippets"
import { ProfileStats } from "@/components/profile/profile-stats"
import { ProfileActivity } from "@/components/profile/profile-activity"

interface UserProfile {
  _id: string
  name: string
  email: string
  username: string
  bio?: string
  location?: string
  website?: string
  githubUsername?: string
  twitterUsername?: string
  createdSnippets: string[]
  savedSnippets: string[]
  followers: string[]
  following: string[]
  joinDate: string
  isFollowing?: boolean
}

interface Snippet {
  _id: string
  title: string
  code: string
  language: string
  tags: string[]
  author: string
  upvotes: number
  createdAt: string
  description?: string
}

export default function PublicProfilePage() {
  const params = useParams()
  const [user, setUser] = useState<UserProfile | null>(null)
  const [snippets, setSnippets] = useState<Snippet[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [currentUser, setCurrentUser] = useState<any>(null)
  const [totalUpvotes, setTotalUpvotes] = useState(0)
  const [activeTab, setActiveTab] = useState("snippets")

  useEffect(() => {
    if (!params?.username) return

    const fetchProfile = async () => {
      try {
        setLoading(true)

        // Check if current user is authenticated
        const authRes = await fetch("http://localhost:5000/api/auth/check", { credentials: "include" })
        const authData = await authRes.json()

        if (authData.authenticated) {
          const userRes = await fetch("http://localhost:5000/api/auth/me", { credentials: "include" })
          const userData = await userRes.json()
          setCurrentUser(userData)
        }

        // Fetch public profile
        const profileRes = await fetch(`http://localhost:5000/api/users/profile/${params.username}`)
        if (!profileRes.ok) {
          if (profileRes.status === 404) {
            return notFound()
          }
          throw new Error("Failed to fetch profile")
        }
        const profileData = await profileRes.json()
        setUser(profileData)

        // Fetch user's public snippets
        if (profileData.createdSnippets?.length) {
          const snippetPromises = profileData.createdSnippets.map((id: string) =>
            fetch(`http://localhost:5000/api/snippets/${id}`).then((res) => res.json()),
          )
          const snippetsData = await Promise.all(snippetPromises)
          const validSnippets = snippetsData.filter(Boolean)
          setSnippets(validSnippets)

          // Calculate total upvotes
          const upvotes = validSnippets.reduce((total, snippet) => total + (snippet.upvotes || 0), 0)
          setTotalUpvotes(upvotes)
        }

        setLoading(false)
      } catch (err) {
        console.error("Error fetching profile:", err)
        setError("Failed to load profile. Please try again later.")
        setLoading(false)
      }
    }

    fetchProfile()
  }, [params?.username])

  const handleFollow = async () => {
    if (!currentUser || !user) return

    try {
      const action = user.isFollowing ? "unfollow" : "follow"
      const res = await fetch(`http://localhost:5000/api/users/${action}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ userId: user._id }),
      })

      if (res.ok) {
        setUser({
          ...user,
          isFollowing: !user.isFollowing,
          followers: user.isFollowing
            ? user.followers.filter((id) => id !== currentUser._id)
            : [...user.followers, currentUser._id],
        })
      }
    } catch (error) {
      console.error("Error following/unfollowing user:", error)
    }
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${user?.name}'s Profile - SnipCove`,
          text: `Check out ${user?.name}'s code snippets on SnipCove`,
          url: window.location.href,
        })
      } catch (error) {
        console.error("Error sharing:", error)
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href)
      // You could show a toast notification here
    }
  }

  if (loading) {
    return (
      <div className="container mx-auto py-8 md:py-12 px-4 text-center">
        <div className="inline-block p-3 rounded-full bg-muted mb-4">
          <User className="h-6 w-6 text-muted-foreground animate-spin" />
        </div>
        <h3 className="text-xl font-medium mb-2">Loading profile...</h3>
        <p className="text-muted-foreground">Please wait while we fetch the user data</p>
      </div>
    )
  }

  if (error || !user) {
    return (
      <div className="container mx-auto py-8 md:py-12 px-4 text-center">
        <div className="inline-block p-3 rounded-full bg-muted mb-4">
          <User className="h-6 w-6 text-destructive" />
        </div>
        <h3 className="text-xl font-medium mb-2">Profile not found</h3>
        <p className="text-muted-foreground mb-6">{error || "This user profile doesn't exist."}</p>
        <Link href="/snippets">
          <Button>Browse Snippets</Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6 md:py-12 px-4">
      <ProfileHeader
        user={user}
        currentUser={currentUser}
        totalUpvotes={totalUpvotes}
        snippetCount={snippets.length}
        onFollow={handleFollow}
        onShare={handleShare}
      />

      <Tabs defaultValue="snippets" value={activeTab} onValueChange={setActiveTab} className="mt-6 md:mt-8">
        <TabsList className="grid grid-cols-3 w-full max-w-md mx-auto">
          <TabsTrigger value="snippets" className="text-xs md:text-sm">
            Snippets
            {snippets.length > 0 && (
              <Badge variant="secondary" className="ml-1 md:ml-2 text-[10px] md:text-xs">
                {snippets.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="stats" className="text-xs md:text-sm">
            Stats
          </TabsTrigger>
          <TabsTrigger value="activity" className="text-xs md:text-sm">
            Activity
          </TabsTrigger>
        </TabsList>

        <div className="mt-4 md:mt-6">
          <TabsContent value="snippets">
            <ProfileSnippets snippets={snippets} />
          </TabsContent>

          <TabsContent value="stats">
            <ProfileStats
              user={user}
              snippets={snippets}
              totalUpvotes={totalUpvotes}
              languages={[...new Set(snippets.map((s) => s.language))]}
            />
          </TabsContent>

          <TabsContent value="activity">
            <ProfileActivity user={user} snippets={snippets} />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}
