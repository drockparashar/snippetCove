"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { PublicProfileLayout } from "@/components/public-profile/public-profile-layout"

// Dummy data - replace with actual API call later
const getDummyUserData = (id: string) => {
  return {
    _id: id,
    name: "Alex Johnson",
    username: "alexdev",
    email: "alex@example.com",
    bio: "Full-stack developer passionate about clean code and modern web technologies. Building the future one snippet at a time.",
    location: "San Francisco, CA",
    website: "https://alexjohnson.dev",
    githubUsername: "alexdev",
    twitterUsername: "alexdev",
    avatar: "/placeholder.svg?height=120&width=120",
    joinDate: "2023-01-15",
    isVerified: true,
    stats: {
      publicSnippets: 47,
      totalUpvotes: 1284,
      followers: 156,
      following: 89,
      totalViews: 12500,
    },
    pinnedSnippets: [
      {
        _id: "1",
        title: "React Custom Hook for API Calls",
        description: "A reusable custom hook for handling API requests with loading states and error handling",
        language: "TypeScript",
        tags: ["react", "hooks", "api"],
        upvotes: 234,
        views: 1200,
        createdAt: "2024-01-15",
      },
      {
        _id: "2",
        title: "CSS Grid Layout Helper",
        description: "Utility classes for creating responsive grid layouts with CSS Grid",
        language: "CSS",
        tags: ["css", "grid", "responsive"],
        upvotes: 189,
        views: 890,
        createdAt: "2024-01-10",
      },
      {
        _id: "3",
        title: "Node.js JWT Authentication",
        description: "Complete JWT authentication setup with refresh tokens and middleware",
        language: "JavaScript",
        tags: ["nodejs", "jwt", "auth"],
        upvotes: 312,
        views: 1500,
        createdAt: "2024-01-05",
      },
    ],
    recentSnippets: [
      {
        _id: "4",
        title: "Python Data Validation",
        description: "Pydantic models for robust data validation",
        language: "Python",
        tags: ["python", "validation"],
        upvotes: 45,
        views: 234,
        createdAt: "2024-01-20",
      },
      {
        _id: "5",
        title: "Vue 3 Composition API",
        description: "Modern Vue 3 patterns with Composition API",
        language: "Vue",
        tags: ["vue", "composition"],
        upvotes: 67,
        views: 345,
        createdAt: "2024-01-18",
      },
    ],
    languages: [
      { name: "TypeScript", count: 15, percentage: 32 },
      { name: "JavaScript", count: 12, percentage: 26 },
      { name: "Python", count: 8, percentage: 17 },
      { name: "CSS", count: 6, percentage: 13 },
      { name: "Vue", count: 4, percentage: 8 },
      { name: "Other", count: 2, percentage: 4 },
    ],
    activityData: {
      thisWeek: 3,
      thisMonth: 12,
      thisYear: 47,
      streak: 15,
    },
  }
}

export default function UserProfilePage() {
  const params = useParams()
  const [userData, setUserData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!params?.id) return

    // Simulate API call with dummy data
    setTimeout(() => {
      const data = getDummyUserData(params.id as string)
      setUserData(data)
      setLoading(false)
    }, 500)

    // TODO: Replace with actual API call
    // fetch(`/api/users/${params.id}`)
    //   .then(res => res.json())
    //   .then(data => {
    //     setUserData(data)
    //     setLoading(false)
    //   })
    //   .catch(err => {
    //     console.error('Error fetching user:', err)
    //     setLoading(false)
    //   })
  }, [params?.id])

  if (loading) {
    return <PublicProfileLayout userData={null} loading={true} />
  }

  if (!userData) {
    return <PublicProfileLayout userData={null} loading={false} />
  }

  return <PublicProfileLayout userData={userData} loading={false} />
}
