"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import {
  Calendar,
  Github,
  Globe,
  MapPin,
  Share2,
  Twitter,
  UserPlus,
  Verified,
  Users,
  Eye,
  Star,
  Code2,
} from "lucide-react"
import Link from "next/link"
import type { UserProfileData } from "@/types/user"
import { formatNumber } from "@/lib/utils"

interface ProfileHeaderProps {
  userData: UserProfileData
}

export function ProfileHeader({ userData }: ProfileHeaderProps) {
  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${userData.name}'s Profile - SnipCove`,
          text: `Check out ${userData.name}'s code snippets on SnipCove`,
          url: window.location.href,
        })
      } catch (error) {
        console.error("Error sharing:", error)
      }
    } else {
      await navigator.clipboard.writeText(window.location.href)
      // You could add a toast notification here
    }
  }

  const joinDate = new Date(userData.joinDate).toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  })

  return (
    <div className="border-b bg-muted/30">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-6 lg:gap-8">
          {/* Left Column - Profile Info */}
          <div className="flex flex-col items-center lg:items-start lg:w-80">
            {/* Avatar and Basic Info */}
            <div className="flex flex-col items-center lg:items-start gap-4 mb-6">
              <Avatar className="h-32 w-32 border-4 border-background">
                <AvatarImage src={userData.avatar || "/placeholder.svg?height=128&width=128"} alt={userData.name} />
                <AvatarFallback className="text-3xl">{userData.name.charAt(0).toUpperCase()}</AvatarFallback>
              </Avatar>

              <div className="text-center lg:text-left">
                <div className="flex items-center justify-center lg:justify-start gap-2 mb-1">
                  <h1 className="text-2xl font-bold">{userData.name}</h1>
                  {userData.isVerified && <Verified className="h-5 w-5 text-blue-500 fill-blue-500" />}
                </div>
                <p className="text-muted-foreground text-lg">@{userData.username}</p>
              </div>
            </div>

            {/* Bio */}
            {userData.bio && <p className="text-center lg:text-left mb-4 max-w-md">{userData.bio}</p>}

            {/* Meta Information */}
            <div className="flex flex-col gap-2 text-sm text-muted-foreground mb-4">
              {userData.location && (
                <div className="flex items-center justify-center lg:justify-start gap-2">
                  <MapPin className="h-4 w-4" />
                  {userData.location}
                </div>
              )}
              <div className="flex items-center justify-center lg:justify-start gap-2">
                <Calendar className="h-4 w-4" />
                Joined {joinDate}
              </div>
            </div>

            {/* Social Links */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-2 mb-4">
              {userData.website && (
                <Link href={userData.website} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" size="sm" className="h-8">
                    <Globe className="h-3 w-3 mr-1" />
                    Website
                  </Button>
                </Link>
              )}
              {userData.githubUsername && (
                <Link href={`https://github.com/${userData.githubUsername}`} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" size="sm" className="h-8">
                    <Github className="h-3 w-3 mr-1" />
                    GitHub
                  </Button>
                </Link>
              )}
              {userData.twitterUsername && (
                <Link
                  href={`https://twitter.com/${userData.twitterUsername}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button variant="outline" size="sm" className="h-8">
                    <Twitter className="h-3 w-3 mr-1" />
                    Twitter
                  </Button>
                </Link>
              )}
            </div>

            {/* Follow/Share Buttons */}
            <div className="flex gap-2 w-full lg:w-auto">
              <Button size="sm" className="flex-1 lg:flex-none">
                <UserPlus className="h-3 w-3 mr-1" />
                Follow
              </Button>
              <Button variant="outline" size="sm" onClick={handleShare}>
                <Share2 className="h-3 w-3 mr-1" />
                Share
              </Button>
            </div>
          </div>

          {/* Right Column - Stats and Activity */}
          <div className="flex-1">
            {/* Main Stats Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 mb-6">
              <div className="text-center p-4 bg-background rounded-lg border">
                <div className="text-2xl font-bold">{formatNumber(userData.stats.publicSnippets)}</div>
                <div className="text-sm text-muted-foreground">Snippets</div>
              </div>
              <div className="text-center p-4 bg-background rounded-lg border">
                <div className="text-2xl font-bold">{formatNumber(userData.stats.totalUpvotes)}</div>
                <div className="text-sm text-muted-foreground">Upvotes</div>
              </div>
              <div className="text-center p-4 bg-background rounded-lg border">
                <div className="text-2xl font-bold">{formatNumber(userData.stats.totalViews)}</div>
                <div className="text-sm text-muted-foreground">Views</div>
              </div>
              <div className="text-center p-4 bg-background rounded-lg border">
                <div className="text-2xl font-bold">{formatNumber(userData.stats.followers)}</div>
                <div className="text-sm text-muted-foreground">Followers</div>
              </div>
              <div className="text-center p-4 bg-background rounded-lg border">
                <div className="text-2xl font-bold">{formatNumber(userData.stats.following)}</div>
                <div className="text-sm text-muted-foreground">Following</div>
              </div>
            </div>

            {/* Activity Summary Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="flex items-center gap-3 p-4 bg-background rounded-lg border">
                <div className="p-2 bg-green-100 dark:bg-green-900/20 rounded-lg">
                  <Code2 className="h-5 w-5 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <div className="font-semibold">{userData.activityData.thisWeek}</div>
                  <div className="text-xs text-muted-foreground">This week</div>
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 bg-background rounded-lg border">
                <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-lg">
                  <Star className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <div className="font-semibold">{userData.activityData.thisMonth}</div>
                  <div className="text-xs text-muted-foreground">This month</div>
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 bg-background rounded-lg border">
                <div className="p-2 bg-purple-100 dark:bg-purple-900/20 rounded-lg">
                  <Eye className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                </div>
                <div>
                  <div className="font-semibold">{userData.activityData.thisYear}</div>
                  <div className="text-xs text-muted-foreground">This year</div>
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 bg-background rounded-lg border">
                <div className="p-2 bg-orange-100 dark:bg-orange-900/20 rounded-lg">
                  <Users className="h-5 w-5 text-orange-600 dark:text-orange-400" />
                </div>
                <div>
                  <div className="font-semibold">{userData.activityData.streak}</div>
                  <div className="text-xs text-muted-foreground">Day streak</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
