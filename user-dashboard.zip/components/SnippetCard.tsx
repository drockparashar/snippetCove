"use client"

import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart } from "lucide-react"

interface Snippet {
  _id: string
  title: string
  code: string
  language: string
  tags: string[]
  author: string
  upvotes: number
  createdAt: string
}

interface SnippetCardProps {
  snippet: Snippet
}

export default function SnippetCard({ snippet }: SnippetCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{snippet.title}</CardTitle>
        <CardDescription>
          {snippet.tags.map((tag) => (
            <Badge key={tag}>{tag}</Badge>
          ))}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-2">
        <p className="text-sm text-muted-foreground">Language: {snippet.language}</p>
        <p className="text-sm text-muted-foreground">Created At: {new Date(snippet.createdAt).toLocaleDateString()}</p>
        <div className="flex items-center justify-between">
          <Link href={`/snippets/${snippet._id}`}>View Snippet</Link>
          <div className="flex items-center">
            <Heart className="h-4 w-4 mr-1" />
            {snippet.upvotes}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
